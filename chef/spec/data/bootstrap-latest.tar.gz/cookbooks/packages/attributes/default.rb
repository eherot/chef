# Toggle for recipes to determine if we should rely on distribution packages
# or gems.
default[:packages][:dist_only] = false
